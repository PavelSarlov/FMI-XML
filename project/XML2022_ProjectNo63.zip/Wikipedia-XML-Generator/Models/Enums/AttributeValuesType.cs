﻿namespace Wikipedia_XML_Generator.Models.Enums
{
    public enum AttributeValuesType
    {
        FIXED = 1,
        IMPLIED = 2,
        REQUIRED = 3,
        VALUE = 4
    }
}
